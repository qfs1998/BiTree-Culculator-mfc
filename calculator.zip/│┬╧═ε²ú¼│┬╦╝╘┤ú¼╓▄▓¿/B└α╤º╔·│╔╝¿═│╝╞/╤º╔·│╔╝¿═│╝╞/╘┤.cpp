#include"�ɼ�ͳ��.h"
int main()
{
	int i;
	BiTree T = NULL;
	menu(T);
	while (1)
	{
		menu(T);
	}
	system("pause");
	return 0;
}