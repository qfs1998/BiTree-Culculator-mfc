
// BiTree Culculator mfcDlg.h : ͷ�ļ�
//

#pragma once


// CBiTreeCulculatormfcDlg �Ի���
class CBiTreeCulculatormfcDlg : public CDialogEx
{
// ����
public:
	CBiTreeCulculatormfcDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_BITREECULCULATORMFC_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	// ��׺����ʽ
	CString Infix_Formula;
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnBnClickedButton10();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton2num9();
	afx_msg void OnBnClickedButton4num8();
	afx_msg void OnBnClickedButton3num7();
	afx_msg void OnBnClickedButton5num6();
	afx_msg void OnBnClickedButton6num5();
	afx_msg void OnBnClickedButton7num4();
	afx_msg void OnBnClickedButton8num3();
	afx_msg void OnBnClickedButton9num2();
	afx_msg void OnBnClickedButton10num1();
	afx_msg void OnBnClickedButton11num0();
	afx_msg void OnBnClickedButton12point();
	afx_msg void OnBnClickedButton16plus();
	afx_msg void OnBnClickedButton17minus();
	afx_msg void OnBnClickedButton14lpare();
	afx_msg void OnBnClickedButton13rpare();
	afx_msg void OnBnClickedButton18multiply();
	afx_msg void OnBnClickedButton15divide();
	afx_msg void OnBnClickedButton1clear();
	afx_msg void OnBnClickedButton2culculate();
	CString culresult;
	afx_msg void OnBnClickedButton8j();
};
