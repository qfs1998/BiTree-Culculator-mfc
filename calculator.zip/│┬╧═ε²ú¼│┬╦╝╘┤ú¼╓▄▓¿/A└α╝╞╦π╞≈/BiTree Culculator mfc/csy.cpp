#include "stdafx.h"
#include "BiTree Culculator mfc.h"
#include "BiTree Culculator mfcDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include"culculator.h"
#define MAXSIZE 1000
//��������ʽת��������
/*
afaΪָ�����ʽ�ַ�����ָ��
sΪҪת���ı���ʽ�ַ�������ʼλ��
eΪҪת���ı���ʽ�ַ����Ľ���λ�õĺ�һ��
*/
BtreeNode* afaToBtree(char *afa, int s, int e) {
	//���Ҫת���ı����ַ������������Ǿ���Ҷ�ӽ����
	int END = 0;
	for (int i = s; i<e; i++)
	{
		if (afa[i] >= '0'&&afa[i] <= '9') {}
		else if (afa[i] == 'j')
		{
			END++;
		}
		else { END += 2; }
	}
	if (END == 0)
	{
		BtreeNode* bn = (struct BtreeNode*)malloc(sizeof(struct BtreeNode));
		memset(bn->data, '\0', sizeof(bn->data));
		for (int i = 0; i<(e - s); i++)
		{
			bn->data[i] = afa[s + i];
		}
		bn->lchild = NULL;
		bn->rchild = NULL;
		return bn;
	}
	else if (END == 1)
	{
		if ((e - s) == 1)
		{
			BtreeNode* bn = (struct BtreeNode*)malloc(sizeof(struct BtreeNode));
			BtreeNode* bn1 = (struct BtreeNode*)malloc(sizeof(struct BtreeNode));
			memset(bn->data, '\0', sizeof(bn->data));
			memset(bn1->data, '\0', sizeof(bn1->data));
			bn1->data[0] = '1';
			bn1->lchild = NULL;
			bn1->rchild = NULL;
			bn->data[0] = afa[s];
			bn->lchild = bn1;
			bn->rchild = NULL;
			return bn;
		}
		else {
			BtreeNode* bn = (struct BtreeNode*)malloc(sizeof(struct BtreeNode));
			BtreeNode* bn1 = (struct BtreeNode*)malloc(sizeof(struct BtreeNode));
			memset(bn->data, '\0', sizeof(bn->data));
			memset(bn1->data, '\0', sizeof(bn1->data));
			for (int i = 0; i<(e - s - 1); i++)
			{
				bn1->data[i] = afa[s + i];
			}
			bn1->lchild = NULL;
			bn1->rchild = NULL;
			bn->data[0] = afa[e - 1];
			bn->lchild = bn1;
			bn->rchild = NULL;
			return bn;
		}
	}
	/*
	local_r��¼��ǰҪת���ı���ʽ���ɶ������ĸ��ڵ��������λ��
	flag��¼�Ƿ�ǰ��������������
	a_s_p��¼��ǰ����ʽ�������������ұߵ�+��-λ��
	m_m_p��¼��ǰ����ʽ�������������ұߵ�*��/λ��
	*/
	int local_r = 0, flag = 0;
	int m_m_p = 0, a_s_p = 0;
	for (int i = s; i<e; i++)
	{
		if (afa[i] == '(')flag++;
		else if (afa[i] == ')')flag--;
		if (flag == 0) {
			if (afa[i] == '*' || afa[i] == '/')
				m_m_p = i;
			else if (afa[i] == '+' || afa[i] == '-')
				a_s_p = i;
		}
	}
	if ((m_m_p == 0) && (a_s_p == 0))
		//���ʽ��������������(5-2*3+7)������������û�в���������ȥ�������Ҷ�����
	{
		BtreeNode* b = afaToBtree(afa, s + 1, e - 1);
		return b;
	}
	else
	{
		//�����+����-������ڵ�Ϊ���ұߵ�+��-�����������ұߵ�*��/
		if (a_s_p>0)local_r = a_s_p;
		else if (m_m_p>0)local_r = m_m_p;
		//ȷ�����ڵ�͸��ڵ�����Ӻ��Һ���
		BtreeNode* b = (struct BtreeNode*)malloc(sizeof(struct BtreeNode));
		memset(b->data, '\0', sizeof(b->data));
		b->data[0] = afa[local_r];
		b->lchild = afaToBtree(afa, s, local_r);
		b->rchild = afaToBtree(afa, local_r + 1, e);
		return b;
	}
}

int cal(LinkList exp,string &s)
{
	stringstream ss;
	double r1, r2, i1, i2;
	SqStack RE, IM;
	RE.base = (double *)malloc(MAXSIZE * sizeof(double));
	RE.top = RE.base;
	RE.Size = MAXSIZE;
	IM.base = (double *)malloc(MAXSIZE * sizeof(double));
	IM.top = IM.base;
	IM.Size = MAXSIZE;
	while (exp != NULL)
	{
		if (exp->re[0] == '+')
		{
			RE.top--; IM.top--;
			r2 = *(RE.top); i2 = *(IM.top);
			RE.top--; IM.top--;
			r1 = *(RE.top); i1 = *(IM.top);
			*(RE.top) = r1 + r2; *(IM.top) = i1 + i2;
			RE.top++; IM.top++;
			LinkNode* p = exp;
			exp = exp->next;
			free(p);
		}
		else if (exp->re[0] == '-')
		{
			RE.top--; IM.top--;
			r2 = *(RE.top); i2 = *(IM.top);
			RE.top--; IM.top--;
			r1 = *(RE.top); i1 = *(IM.top);
			*(RE.top) = r1 - r2; *(IM.top) = i1 - i2;
			RE.top++; IM.top++;
			LinkNode* p = exp;
			exp = exp->next;
			free(p);
		}
		else if (exp->re[0] == '*')
		{
			RE.top--; IM.top--;
			r2 = *(RE.top); i2 = *(IM.top);
			RE.top--; IM.top--;
			r1 = *(RE.top); i1 = *(IM.top);
			*(RE.top) = r1*r2 - i1*i2; *(IM.top) = r1*i2 + r2*i1;
			RE.top++; IM.top++;
			LinkNode* p = exp;
			exp = exp->next;
			free(p);
		}
		else if (exp->re[0] == '/')
		{
			RE.top--; IM.top--;
			r2 = *(RE.top); i2 = *(IM.top);
			if (r2 == 0 && i2 == 0)
			{
				s = "�������";
				return 0;
			}
			RE.top--; IM.top--;
			r1 = *(RE.top); i1 = *(IM.top);
			*(RE.top) = (r1*r2 + i1*i2) / (r2*r2 + i2*i2); *(IM.top) = (r2*i1 - r1*i2) / (r2*r2 + i2*i2);
			RE.top++; IM.top++;
			LinkNode* p = exp;
			exp = exp->next;
			free(p);
		}
		else
		{
			*(RE.top) = atoi(exp->re); *IM.top = atoi(exp->im);
			RE.top++; IM.top++;
			LinkNode* p = exp;
			exp = exp->next;
			free(p);
		}
	}
	if (*(RE.base) == 0 && *(IM.base) == 0)
	{
		s = "0";
	}
	else
	{
		if (*(RE.base) == 0)
		{
			ss << *(IM.base);
			ss << "j";
			ss >> s;
		}
		else if (*(IM.base) == 0)
		{
			ss << *(RE.base);
			ss << s;
		}
		else if (*(IM.base) > 0)
		{
			ss << *(RE.base);
			ss << "+";
			ss << *(IM.base);
			ss << "j";
			ss >> s;
		}
		else 
		{
			ss << *(RE.base);
			ss << *(IM.base);
			ss << "j";
			ss >> s;
		}
	}
	return 1;
}

void postvisit(Btree T, LinkList &exp)
{
	if (T)
	{
		postvisit(T->lchild, exp);
		postvisit(T->rchild, exp);
		if (T->data[0] == '+' || T->data[0] == '-' || T->data[0] == '*' || T->data[0] == '/')
		{
			LinkNode *p = (LinkNode*)malloc(sizeof(LinkNode));
			memset(p->re, '\0', sizeof(p->re));
			memset(p->im, '\0', sizeof(p->im));
			p->re[0] = T->data[0];
			p->next = exp;
			exp = p;
		}
		else if (T->data[0] == 'j')
		{
			char t[10];
			strcpy_s(t, exp->re);
			strcpy_s(exp->re, exp->im);
			strcpy_s(exp->im, t);
		}
		else
		{
			LinkNode *p = (LinkNode*)malloc(sizeof(LinkNode));
			memset(p->re, '\0', sizeof(p->re));
			memset(p->im, '\0', sizeof(p->im));
			strcpy_s(p->re, T->data);
			p->im[0] = '0';
			p->next = exp;
			exp = p;
		}
	}
}

LinkList trans(LinkList exp)
{
	LinkList L = NULL, p;
	while (exp != NULL)
	{
		p = L;
		L = exp;
		exp = exp->next;
		L->next = p;
	}
	return L;
}

int check(char *input,string&s)
{
	int i, j = 0, t;
	while (input[j] != '\0')
	{
		j++;
	}
	j = j - 1;
	for (i = 0; input[i] != '\0'; i++)
	{
		if ((input[i] == '-'&&i == 0) || (input[i] == '-'&&input[i - 1] == '('))
		{
			for (t = j; t >= i; t--)
			{
				input[t + 1] = input[t];
			}
			input[i] = '0';
			j++;
		}
		else if ((input[i] == '+'&&i == 0) || (input[i] == '+'&&input[i - 1] == '('))
		{
			for (t = i; t<j; t++)
			{
				input[t] = input[t + 1];
			}
			input[j] = '\0';
			j--;
		}
		else if (input[i] == 'j'&&input[i - 1] == ')')
		{
			for (t = j; t >= i; t--)
			{
				input[t + 1] = input[t];
			}
			input[i] = '*';
			j++;
		}
		else
		{
			if ((input[i] >= '0'&&input[i] <= '9') || input[i] == '+' || input[i] == '-' || input[i] == '*' || input[i] == '/' || input[i] == '(' || input[i] == ')' || input[i] == 'j');
			else
			{
				s = "�������";
				return 0;
			}
		}
	}
	return 1;
}